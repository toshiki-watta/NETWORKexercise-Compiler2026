loadi r0 10
store r0 0
loadi r0 2
load r1 0
mulr r0 r1
store r0 1
load r0 0
writed r0
loadi r1 32
writec r1
load r0 1
writed r0
loadi r1 10
writec r1
halt
