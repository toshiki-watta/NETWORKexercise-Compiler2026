loadi r0 526
muli r0 321
writed r0
loadi r1 '\n'
writec r1
halt
